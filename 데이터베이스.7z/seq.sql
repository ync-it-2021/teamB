--------------------------------------------------------
--  ������ ������ - �ݿ���-1��-07-2022   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Sequence SEQ_BOARD
--------------------------------------------------------

   CREATE SEQUENCE  "TEAM2102"."SEQ_BOARD"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 81 CACHE 20 NOORDER  NOCYCLE   ;
--------------------------------------------------------
--  DDL for Sequence SEQ_CART
--------------------------------------------------------

   CREATE SEQUENCE  "TEAM2102"."SEQ_CART"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 61 CACHE 20 NOORDER  NOCYCLE   ;
--------------------------------------------------------
--  DDL for Sequence SEQ_COMMENTS
--------------------------------------------------------

   CREATE SEQUENCE  "TEAM2102"."SEQ_COMMENTS"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE   ;
--------------------------------------------------------
--  DDL for Sequence SEQ_FAQ
--------------------------------------------------------

   CREATE SEQUENCE  "TEAM2102"."SEQ_FAQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE   ;
--------------------------------------------------------
--  DDL for Sequence SEQ_GAMENUM
--------------------------------------------------------

   CREATE SEQUENCE  "TEAM2102"."SEQ_GAMENUM"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 212 CACHE 20 NOORDER  NOCYCLE   ;
--------------------------------------------------------
--  DDL for Sequence SEQ_GENREID
--------------------------------------------------------

   CREATE SEQUENCE  "TEAM2102"."SEQ_GENREID"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 21 CACHE 20 NOORDER  NOCYCLE   ;
--------------------------------------------------------
--  DDL for Sequence SEQ_NEWS
--------------------------------------------------------

   CREATE SEQUENCE  "TEAM2102"."SEQ_NEWS"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 81 CACHE 20 NOORDER  NOCYCLE   ;
--------------------------------------------------------
--  DDL for Sequence SEQ_PAYMENT
--------------------------------------------------------

   CREATE SEQUENCE  "TEAM2102"."SEQ_PAYMENT"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE   ;
--------------------------------------------------------
--  DDL for Sequence SEQ_PURCHASE
--------------------------------------------------------

   CREATE SEQUENCE  "TEAM2102"."SEQ_PURCHASE"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE   ;
--------------------------------------------------------
--  DDL for Sequence SEQ_QNA
--------------------------------------------------------

   CREATE SEQUENCE  "TEAM2102"."SEQ_QNA"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE   ;
--------------------------------------------------------
--  DDL for Sequence SEQ_RECID
--------------------------------------------------------

   CREATE SEQUENCE  "TEAM2102"."SEQ_RECID"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE   ;
--------------------------------------------------------
--  DDL for Sequence SEQ_SIZEID
--------------------------------------------------------

   CREATE SEQUENCE  "TEAM2102"."SEQ_SIZEID"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 21 CACHE 20 NOORDER  NOCYCLE   ;
--------------------------------------------------------
--  DDL for Sequence SEQ_WISHLIST
--------------------------------------------------------

   CREATE SEQUENCE  "TEAM2102"."SEQ_WISHLIST"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE   ;
