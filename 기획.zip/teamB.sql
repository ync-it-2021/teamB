
CREATE SEQUENCE Seq_Cart
	INCREMENT BY 1
	START WITH 1;



CREATE SEQUENCE Seq_Comments
	INCREMENT BY 1
	START WITH 1;



CREATE SEQUENCE Seq_FAQ
	INCREMENT BY 1
	START WITH 1;



CREATE SEQUENCE Seq_GameNum
	INCREMENT BY 1
	START WITH 1;



CREATE SEQUENCE Seq_GenreID
	INCREMENT BY 1
	START WITH 1;



CREATE SEQUENCE Seq_News
	INCREMENT BY 1
	START WITH 1;



CREATE SEQUENCE Seq_Payment
	INCREMENT BY 1
	START WITH 1;



CREATE SEQUENCE Seq_Purchase
	INCREMENT BY 1
	START WITH 1;



CREATE SEQUENCE Seq_QnA
	INCREMENT BY 1
	START WITH 1;



CREATE SEQUENCE Seq_RecID
	INCREMENT BY 1
	START WITH 1;



CREATE SEQUENCE Seq_SizeID
	INCREMENT BY 1
	START WITH 1;



CREATE SEQUENCE Seq_Wishlist
	INCREMENT BY 1
	START WITH 1;



CREATE TABLE Cart
(
	cart_num             NUMBER NOT NULL ,
	quantity             NUMBER NULL ,
	UserID               VARCHAR2(50) NOT NULL ,
	Game_num             NUMBER NOT NULL 
);



CREATE UNIQUE INDEX XPK장바구니 ON Cart
(cart_num   ASC);



ALTER TABLE Cart
	ADD CONSTRAINT  XPK장바구니 PRIMARY KEY (cart_num);



CREATE  INDEX XIF2장바구니 ON Cart
(UserID   ASC);



CREATE  INDEX XIF3장바구니 ON Cart
(Game_num   ASC);



CREATE TABLE Comments
(
	Comment_number       NUMBER NOT NULL ,
	Comment_contents     VARCHAR(400) NULL ,
	news_num             NUMBER NOT NULL 
);



CREATE UNIQUE INDEX XPK댓글 ON Comments
(Comment_number   ASC);



ALTER TABLE Comments
	ADD CONSTRAINT  XPK댓글 PRIMARY KEY (Comment_number);



CREATE  INDEX XIF1댓글 ON Comments
(news_num   ASC);



CREATE TABLE FAQ
(
	FAQ_num              NUMBER NOT NULL ,
	FAQ_Title            VARCHAR2(300) NULL ,
	FAQ_Contents         VARCHAR2(3000) NULL ,
	UserID               VARCHAR2(50) NOT NULL 
);



CREATE UNIQUE INDEX XPKFAQ_자주묻는질문 ON FAQ
(FAQ_num   ASC);



ALTER TABLE FAQ
	ADD CONSTRAINT  XPKFAQ_자주묻는질문 PRIMARY KEY (FAQ_num);



CREATE  INDEX XIF1FAQ_자주묻는질문 ON FAQ
(UserID   ASC);



CREATE TABLE Game_INFO
(
	Game_num             NUMBER NOT NULL ,
	Title                VARCHAR2(50) NOT NULL ,
	Info                 VARCHAR2(3000) NULL ,
	Korean               VARCHAR2(30) NULL ,
	Dev                  VARCHAR2(50) NULL ,
	Publisher            VARCHAR2(50) NULL ,
	Platform             VARCHAR2(50) NULL ,
	Price                NUMBER DEFAULT  0  NOT NULL ,
	Sale_Price           NUMBER NULL ,
	Sale_Enabled         CHAR(1) DEFAULT  0
  NOT NULL ,
	Relase_date          DATE NULL ,
	FILE_1               VARCHAR2(1000) NULL ,
	FILE_2               VARCHAR2(1000) NULL ,
	FILE_3               VARCHAR2(1000) NULL ,
	Genre_id             NUMBER NOT NULL ,
	Size_id              NUMBER NOT NULL ,
	Rec_id               NUMBER NOT NULL 
);



CREATE UNIQUE INDEX XPK게임_정보 ON Game_INFO
(Game_num   ASC);



ALTER TABLE Game_INFO
	ADD CONSTRAINT  XPK게임_정보 PRIMARY KEY (Game_num);



CREATE  INDEX XIF1게임_정보 ON Game_INFO
(Genre_id   ASC);



CREATE  INDEX XIF2게임_정보 ON Game_INFO
(Size_id   ASC);



CREATE  INDEX XIF3게임_정보 ON Game_INFO
(Rec_id   ASC);



CREATE TABLE Genre
(
	Genre_id             NUMBER NOT NULL ,
	Genre_name           VARCHAR2(100) NULL 
);



CREATE UNIQUE INDEX XPK장르 ON Genre
(Genre_id   ASC);



ALTER TABLE Genre
	ADD CONSTRAINT  XPK장르 PRIMARY KEY (Genre_id);



CREATE TABLE member
(
	UserID               VARCHAR2(50) NOT NULL ,
	UserMail             VARCHAR2(100) NULL ,
	UserPhone            NUMBER NULL ,
	UserName             VARCHAR2(100) NULL ,
	UserPW               VARCHAR2(100) NOT NULL ,
	RegDate              DATE DEFAULT SYSDATE NOT NULL ,
	AUTH                 VARCHAR2(50) NULL ,
	Enabled              CHAR(1) DEFAULT  1  NULL 
);



CREATE UNIQUE INDEX XPK회원정보 ON member
(UserID   ASC);



ALTER TABLE member
	ADD CONSTRAINT  XPK회원정보 PRIMARY KEY (UserID);



CREATE TABLE News
(
	news_num             NUMBER NOT NULL ,
	News_title           VARCHAR(40) NULL ,
	Gubun                VARCHAR(20) NULL ,
	News_date            DATE NULL ,
	FILE_1               VARCHAR(100) NULL ,
	News_contents        VARCHAR(1000) NULL ,
	FILE_2               VARCHAR(100) NULL ,
	UserID               VARCHAR2(50) NOT NULL ,
	FILE_3               VARCHAR2(1000) NULL 
);



CREATE UNIQUE INDEX XPK뉴스 ON News
(news_num   ASC);



ALTER TABLE News
	ADD CONSTRAINT  XPK뉴스 PRIMARY KEY (news_num);



CREATE  INDEX XIF1뉴스 ON News
(UserID   ASC);



CREATE TABLE payment
(
	pay_num              NUMBER NOT NULL ,
	pay_banknum          VARCHAR2(500) NULL ,
	pay_price            NUMBER NULL ,
	pay_date             DATE DEFAULT  SYSDATE  NOT NULL ,
	pay_phonenum         NVARCHAR2(50) NULL ,
	cart_num             NUMBER NOT NULL 
);



CREATE UNIQUE INDEX Te_XPK_buy ON payment
(pay_num   ASC);



ALTER TABLE payment
	ADD CONSTRAINT  Te_XPK_buy PRIMARY KEY (pay_num);



CREATE  INDEX XIF1결제 ON payment
(cart_num   ASC);



CREATE TABLE payment_detail
(
	count                NUMBER NULL ,
	pay_num              NUMBER NOT NULL ,
	UserID               VARCHAR2(50) NULL 
);



CREATE UNIQUE INDEX Te_XPK_order ON payment_detail
(pay_num   ASC);



ALTER TABLE payment_detail
	ADD CONSTRAINT  Te_XPK_order PRIMARY KEY (pay_num);



CREATE  INDEX XIF3결제상세 ON payment_detail
(UserID   ASC);





CREATE TABLE Promotion
(
	Pro_Title            VARCHAR2(300) NULL ,
	Pro_Contents         VARCHAR2(3000) NULL ,
	Pro_Date             DATE NULL ,
	news_num             NUMBER NOT NULL ,
	FILE_1               VARCHAR2(1000 BYTE) NULL ,
	FILE_2               VARCHAR2(1000) NULL ,
	FILE_3               VARCHAR2(1000) NULL 
);



CREATE UNIQUE INDEX XPK프로모션 ON Promotion
(news_num   ASC);



ALTER TABLE Promotion
	ADD CONSTRAINT  XPK프로모션 PRIMARY KEY (news_num);



CREATE TABLE Purchase
(
	Pur_date             DATE NULL ,
	Pur_Price            NUMBER NULL ,
	Pur_Status           NUMBER NULL ,
	method               VARCHAR2(50) NULL ,
	Purchase_num         NUMBER NOT NULL ,
	pay_num              NUMBER NOT NULL ,
	UserID               VARCHAR2(50) NOT NULL 
);



CREATE UNIQUE INDEX XPK구매내역 ON Purchase
(Purchase_num   ASC);



ALTER TABLE Purchase
	ADD CONSTRAINT  XPK구매내역 PRIMARY KEY (Purchase_num);



CREATE  INDEX XIF1구매내역 ON Purchase
(UserID   ASC);



CREATE  INDEX XIF4구매내역 ON Purchase
(pay_num   ASC);



CREATE TABLE QnA
(
	QnA_num              NUMBER NOT NULL ,
	Gubun                VARCHAR2(50) NULL ,
	QnA_Title            VARCHAR2(300) NULL ,
	QnA_Contents         VARCHAR2(3000) NULL ,
	Regist_Date          DATE DEFAULT SYSDATE NOT NULL ,
	Answer_Ability       CHAR(1) DEFAULT  0
  NULL ,
	UserID               VARCHAR2(50) NOT NULL 
);



CREATE UNIQUE INDEX XPK문의 ON QnA
(QnA_num   ASC);



ALTER TABLE QnA
	ADD CONSTRAINT  XPK문의 PRIMARY KEY (QnA_num);



CREATE  INDEX XIF1문의 ON QnA
(UserID   ASC);



CREATE TABLE QnA_ans
(
	QnA_num              NUMBER NOT NULL ,
	Answer_Contents      VARCHAR2(3000) NULL ,
	Reporting_Date       DATE NULL ,
	UserID               VARCHAR2(50) NOT NULL 
);



CREATE UNIQUE INDEX XPK문의_답변 ON QnA_ans
(QnA_num   ASC);



ALTER TABLE QnA_ans
	ADD CONSTRAINT  XPK문의_답변 PRIMARY KEY (QnA_num);



CREATE  INDEX XIF2문의_답변 ON QnA_ans
(UserID   ASC);



CREATE TABLE Recommend
(
	Rec_id               NUMBER NOT NULL ,
	cpu                  VARCHAR2(100) NULL ,
	vga                  VARCHAR2(100) NULL ,
	ram                  VARCHAR2(100) NULL ,
	OS                   VARCHAR2(100) NULL ,
	Network              VARCHAR2(100) NULL ,
	spaces               VARCHAR2(100) NULL 
);



CREATE UNIQUE INDEX XPK요구사양 ON Recommend
(Rec_id   ASC);



ALTER TABLE Recommend
	ADD CONSTRAINT  XPK요구사양 PRIMARY KEY (Rec_id);



CREATE TABLE Size_spec
(
	Size_id              NUMBER NOT NULL ,
	Size_name            VARCHAR2(100) NULL 
);



CREATE UNIQUE INDEX XPK규모 ON Size_spec
(Size_id   ASC);



ALTER TABLE Size_spec
	ADD CONSTRAINT  XPK규모 PRIMARY KEY (Size_id);



CREATE TABLE Wishlist
(
	w_num                NUMBER NOT NULL ,
	w_quantity           NUMBER NULL ,
	UserID               VARCHAR2(50) NOT NULL ,
	Game_num             NUMBER NOT NULL 
);



CREATE UNIQUE INDEX XPK위시리스트 ON Wishlist
(w_num   ASC);



ALTER TABLE Wishlist
	ADD CONSTRAINT  XPK위시리스트 PRIMARY KEY (w_num);



CREATE  INDEX XIF2위시리스트 ON Wishlist
(UserID   ASC);



CREATE  INDEX XIF3위시리스트 ON Wishlist
(Game_num   ASC);



ALTER TABLE Cart
	ADD (CONSTRAINT R_29 FOREIGN KEY (UserID) REFERENCES member (UserID));



ALTER TABLE Cart
	ADD (CONSTRAINT R_84 FOREIGN KEY (Game_num) REFERENCES Game_INFO (Game_num));



ALTER TABLE Comments
	ADD (CONSTRAINT R_1 FOREIGN KEY (news_num) REFERENCES News (news_num));



ALTER TABLE FAQ
	ADD (CONSTRAINT R_67 FOREIGN KEY (UserID) REFERENCES member (UserID));



ALTER TABLE Game_INFO
	ADD (CONSTRAINT R_76 FOREIGN KEY (Genre_id) REFERENCES Genre (Genre_id));



ALTER TABLE Game_INFO
	ADD (CONSTRAINT R_77 FOREIGN KEY (Size_id) REFERENCES Size_spec (Size_id));



ALTER TABLE Game_INFO
	ADD (CONSTRAINT R_78 FOREIGN KEY (Rec_id) REFERENCES Recommend (Rec_id));



ALTER TABLE News
	ADD (CONSTRAINT R_72 FOREIGN KEY (UserID) REFERENCES member (UserID));



ALTER TABLE payment
	ADD (CONSTRAINT R_62 FOREIGN KEY (cart_num) REFERENCES Cart (cart_num));



ALTER TABLE payment_detail
	ADD (CONSTRAINT R_60 FOREIGN KEY (pay_num) REFERENCES payment (pay_num));



ALTER TABLE payment_detail
	ADD (CONSTRAINT R_64 FOREIGN KEY (UserID) REFERENCES member (UserID));



ALTER TABLE Promotion
	ADD (CONSTRAINT R_49 FOREIGN KEY (news_num) REFERENCES News (news_num));



ALTER TABLE Purchase
	ADD (CONSTRAINT R_7 FOREIGN KEY (UserID) REFERENCES member (UserID));



ALTER TABLE Purchase
	ADD (CONSTRAINT R_63 FOREIGN KEY (pay_num) REFERENCES payment (pay_num));



ALTER TABLE QnA
	ADD (CONSTRAINT R_75 FOREIGN KEY (UserID) REFERENCES member (UserID));



ALTER TABLE QnA_ans
	ADD (CONSTRAINT R_37 FOREIGN KEY (QnA_num) REFERENCES QnA (QnA_num));



ALTER TABLE QnA_ans
	ADD (CONSTRAINT R_73 FOREIGN KEY (UserID) REFERENCES member (UserID));



ALTER TABLE Wishlist
	ADD (CONSTRAINT R_33 FOREIGN KEY (UserID) REFERENCES member (UserID));



ALTER TABLE Wishlist
	ADD (CONSTRAINT R_83 FOREIGN KEY (Game_num) REFERENCES Game_INFO (Game_num));